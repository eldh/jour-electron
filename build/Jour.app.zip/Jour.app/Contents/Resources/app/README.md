# Jour

Jour is a simple diary app. 

It's built with Reason, ReasonReact and Electron.